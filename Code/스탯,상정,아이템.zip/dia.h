#include "dia3.c"
#include "Shop_S.c"
#include "Shop_B.c"
#include "Shop_G.c"